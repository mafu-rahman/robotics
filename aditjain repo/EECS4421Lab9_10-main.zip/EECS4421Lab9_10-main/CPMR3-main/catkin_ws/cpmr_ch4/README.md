urdf/scout-bumper.urdf.xaco - a robot with a bumper

urdf/scout-imu.urdf.xaco - a robot with an IMU

urdf/scout-sonar.urdf.xaco - a robot with sonar

urdf/scout-sonar.laser.xaco - a robot with laser

scripts/drive-to-hit.py - drive a bumper equipped robot until it hits something, then back up 

launch/gazebo-bumper.launch - spawn a bumper robot

launch/gazebo-imu.launch - spawn an IMU robot

launch/gazebo-sonar.launch - spawn a sonar-equipped robot

launch/gazebo-laser.launch - spawn a laser-equipped robot
