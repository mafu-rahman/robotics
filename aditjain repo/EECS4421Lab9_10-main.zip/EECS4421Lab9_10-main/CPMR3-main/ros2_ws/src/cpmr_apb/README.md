This package supports
* cpmr_apb gazebo.launch.py  - A launch file that puts a very simple block robot in an empty world
* populate_world  - A ROS application that populates the world with coke cans. Note: This assumes that gazeo has/can download the coke can model. This may result in some delay the first itme it is run.
* depopulate_word - A  ROS application that depopulates the world full of coke cans.

