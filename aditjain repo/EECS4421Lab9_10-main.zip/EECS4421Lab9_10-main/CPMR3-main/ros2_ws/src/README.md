These are packages associated with the chapters in CPMR 3rd Edition.  To build just one (or a selection of the packages) use

colcon build --packages-select <list of packages>

* cpmr_apb Files associated with the tutorial information that can be found at the root of this repository.
* cpmr_ch2 Files assoicated with Chapter 2. 
* cpmr_ch4 Files associated with Chapter 4.
* cpmr_ch5
* cpmr_ch6
* cpmr_ch7
* cpmr_ch11
* cpmr_ch12 Files associated with chapter 12. Note that some of the files here require ultralytics to be installed (pip install -U ultralytics)
* 

